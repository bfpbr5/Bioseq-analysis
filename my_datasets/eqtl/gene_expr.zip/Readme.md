# Gene Expression

## 文件

metadata.txt

​	标注了label中不同列代表的组织，共54个

train.txt

​	共45662个gene

valid.txt

​	6号和9号染色体，共4899个gene

test.txt

​	7号和8号染色体，共4990个gene